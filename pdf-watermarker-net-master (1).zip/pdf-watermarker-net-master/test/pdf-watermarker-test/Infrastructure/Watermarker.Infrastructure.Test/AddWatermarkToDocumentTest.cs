using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
using Watermarker.Domain.Service;
using Watermarker.Domain.ValueObject;
using Watermarker.Domain.ValueObject.Enum;

namespace Watermarker.Infrastructure.Test
{
    [TestClass]
    public class AddWatermarkToDocumentTest
    {
        private readonly IWatermarker<Pdf> _watermarker;
        private readonly string _inputImage;
        private readonly string _inputPdf;
        private readonly string _outputPdf;
        private readonly string _assetsDirectory;

        public AddWatermarkToDocumentTest()
        {
            _watermarker = new PdfSharpCoreWatermarker();

            _assetsDirectory =
                Path.Combine(
                    Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.Parent.Parent.Parent.Parent
                        .FullName, "assets");
            _inputImage = Path.Combine(_assetsDirectory, "star.png");
            _inputPdf = Path.Combine(_assetsDirectory, "test.pdf");
            _outputPdf = Path.Combine(_assetsDirectory, "test-output.pdf");
        }

        [TestMethod]
        public void TestAddWatermarkToPdfTopLeftPosition()
        {
            Pdf pdf = new Pdf(_inputPdf);
            Watermark watermark = Watermark.CreateWatermark(_inputImage, Position.TopLeft, false);

            _watermarker.AddWatermarkToDocument(watermark, pdf);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-topleft-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }
    }
}