using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Watermarker.Application.Request;
using Watermarker.Domain.ValueObject.Enum;
using Watermarker.Infrastructure;

namespace Watermarker.Application.Test
{
    [TestClass]
    public class SavePdfWithWatermarkIntervalPageTest
    {
        private readonly SavePdfWithWatermarkIntervalPage _savePdfWithWatermarkIntervalPage;
        private readonly string _inputImage;
        private readonly string _inputPdf;
        private readonly string _outputPdf;
        private readonly string _assetsDirectory;

        public SavePdfWithWatermarkIntervalPageTest()
        {
            _savePdfWithWatermarkIntervalPage = new SavePdfWithWatermarkIntervalPage(new PdfSharpCoreWatermarker());

            _assetsDirectory =
                Path.Combine(
                    Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.Parent.Parent.Parent.Parent
                        .FullName, "assets");
            _inputImage = Path.Combine(_assetsDirectory, "star.png");
            _inputPdf = Path.Combine(_assetsDirectory, "test-multipage.pdf");
            _outputPdf = Path.Combine(_assetsDirectory, "test-multipage-output.pdf");
        }

        [TestMethod]
        public void TestAddWatermarkToPdfTopLeftPosition()
        {
            var request = new SavePdfWithWatermarkIntervalPageRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                StartPage = 3,
                EndPage = 5,
                Position = Position.TopLeft,
                IsBackground = false
            };
            _savePdfWithWatermarkIntervalPage.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-interval-topleft-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfTopRightPosition()
        {
            var request = new SavePdfWithWatermarkIntervalPageRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                StartPage = 3,
                EndPage = 5,
                Position = Position.TopRight,
                IsBackground = false
            };
            _savePdfWithWatermarkIntervalPage.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(
                new FileInfo(Path.Combine(_assetsDirectory, "output-interval-topright-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfBottomLeftPosition()
        {
            var request = new SavePdfWithWatermarkIntervalPageRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                StartPage = 3,
                EndPage = 5,
                Position = Position.BottomLeft,
                IsBackground = false
            };
            _savePdfWithWatermarkIntervalPage.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(
                new FileInfo(Path.Combine(_assetsDirectory, "output-interval-bottomleft-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfBottomRightPosition()
        {
            var request = new SavePdfWithWatermarkIntervalPageRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                StartPage = 3,
                EndPage = 5,
                Position = Position.BottomRight,
                IsBackground = false
            };
            _savePdfWithWatermarkIntervalPage.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(
                new FileInfo(Path.Combine(_assetsDirectory, "output-interval-bottomright-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfDefaultPosition()
        {
            var request = new SavePdfWithWatermarkIntervalPageRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                StartPage = 3,
                EndPage = 5,
                IsBackground = false
            };
            _savePdfWithWatermarkIntervalPage.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-interval-default-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }
    }
}