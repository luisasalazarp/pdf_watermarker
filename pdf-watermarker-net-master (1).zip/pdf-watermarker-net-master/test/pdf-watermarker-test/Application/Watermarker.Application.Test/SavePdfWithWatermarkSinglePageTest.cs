using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Watermarker.Application.Request;
using Watermarker.Domain.ValueObject.Enum;
using Watermarker.Infrastructure;

namespace Watermarker.Application.Test
{
    [TestClass]
    public class SavePdfWithWatermarkSinglePageTest
    {
        private readonly SavePdfWithWatermarkSinglePage _savePdfWithWatermarkSinglePage;
        private readonly string _inputImage;
        private readonly string _inputPdf;
        private readonly string _outputPdf;
        private readonly string _assetsDirectory;

        public SavePdfWithWatermarkSinglePageTest()
        {
            _savePdfWithWatermarkSinglePage = new SavePdfWithWatermarkSinglePage(new PdfSharpCoreWatermarker());

            _assetsDirectory =
                Path.Combine(
                    Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.Parent.Parent.Parent.Parent
                        .FullName, "assets");
            _inputImage = Path.Combine(_assetsDirectory, "star.png");
            _inputPdf = Path.Combine(_assetsDirectory, "test-single-page.pdf");
            _outputPdf = Path.Combine(_assetsDirectory, "test-single-page-output.pdf");
        }

        [TestMethod]
        public void TestAddWatermarkToPdfTopLeftPosition()
        {
            var request = new SavePdfWithWatermarkSinglePageRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                Index = 2,
                Position = Position.TopLeft,
                IsBackground = false
            };
            _savePdfWithWatermarkSinglePage.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-index-topleft-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfTopRightPosition()
        {
            var request = new SavePdfWithWatermarkSinglePageRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                Index = 2,
                Position = Position.TopRight,
                IsBackground = false
            };
            _savePdfWithWatermarkSinglePage.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-index-topright-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfBottomLeftPosition()
        {
            var request = new SavePdfWithWatermarkSinglePageRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                Index = 2,
                Position = Position.BottomLeft,
                IsBackground = false
            };
            _savePdfWithWatermarkSinglePage.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-index-bottomleft-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfBottomRightPosition()
        {
            var request = new SavePdfWithWatermarkSinglePageRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                Index = 2,

                Position = Position.BottomRight,
                IsBackground = false
            };
            _savePdfWithWatermarkSinglePage.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(
                new FileInfo(Path.Combine(_assetsDirectory, "output-index-bottomright-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfDefaultPosition()
        {
            var request = new SavePdfWithWatermarkSinglePageRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                Index = 2,
                IsBackground = false
            };
            _savePdfWithWatermarkSinglePage.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-index-default-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }
    }
}