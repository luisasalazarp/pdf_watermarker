using System;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Watermarker.Application.Request;
using Watermarker.Domain.ValueObject.Enum;
using Watermarker.Infrastructure;

namespace Watermarker.Application.Test
{
    [TestClass]
    public class SavePdfWithWatermarkTest
    {
        private readonly SavePdfWithWatermark _savePdfWithWatermark;
        private readonly string _inputImage;
        private readonly string _inputPdf;
        private readonly string _outputPdf;

        private readonly string _assetsDirectory;

        public SavePdfWithWatermarkTest()
        {
            _savePdfWithWatermark = new SavePdfWithWatermark(new PdfSharpCoreWatermarker());

            _assetsDirectory =
                Path.Combine(
                    Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.Parent.Parent.Parent.Parent
                        .FullName, "assets");
            _inputImage = Path.Combine(_assetsDirectory, "star.png");
            _inputPdf = Path.Combine(_assetsDirectory, "test.pdf");
            _outputPdf = Path.Combine(_assetsDirectory, "test-output.pdf");
        }

        [TestMethod]
        public void TestAddWatermarkToPdfTopLeftPosition()
        {
            var request = new SavePdfWithWatermarkRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                Position = Position.TopLeft,
                IsBackground = false
            };
            _savePdfWithWatermark.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-topleft-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfTopRightPosition()
        {
            var request = new SavePdfWithWatermarkRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                Position = Position.TopRight,
                IsBackground = false
            };
            _savePdfWithWatermark.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-topright-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfBottomLeftPosition()
        {
            var request = new SavePdfWithWatermarkRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                Position = Position.BottomLeft,
                IsBackground = false
            };
            _savePdfWithWatermark.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-bottomleft-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfBottomRightPosition()
        {
            var request = new SavePdfWithWatermarkRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                Position = Position.BottomRight,
                IsBackground = false
            };
            _savePdfWithWatermark.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-bottomright-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }

        [TestMethod]
        public void TestAddWatermarkToPdfDefaultPosition()
        {
            var request = new SavePdfWithWatermarkRequest
            {
                ImagePath = _inputImage,
                DocumentPath = _inputPdf,
                IsBackground = false
            };
            _savePdfWithWatermark.Execute(request);

            Assert.AreEqual(File.Exists(_outputPdf), true);
            Assert.AreEqual(new FileInfo(Path.Combine(_assetsDirectory, "output-default-position.pdf")).Length,
                new FileInfo(_outputPdf).Length);
        }
    }
}