using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
using Watermarker.Domain.Exception;
using Watermarker.Domain.ValueObject;
using Watermarker.Domain.ValueObject.Enum;

namespace Watermarker.Domain.Test
{
    [TestClass]
    public class WatermarkTest
    {
        protected string assetsDirectory;

        public WatermarkTest()
        {
            assetsDirectory =
                Path.Combine(Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System)),
                    "pdfwatermark", "assets");
        }

        [TestMethod]
        public void TestWatermarkType()
        {
            string message = string.Empty;
            try
            {
                Watermark.CreateWatermark(Path.Combine(assetsDirectory, "star.gif"), Position.Center, false);
            }
            catch (FileFormatException ex)
            {
                message = ex.Message;
            }

            Assert.AreEqual(message, "Invalid image type");
        }

        [TestMethod]
        public void TestWatermarkExist()
        {
            string message = string.Empty;
            try
            {
                Watermark.CreateWatermark(Path.Combine(assetsDirectory, "star2.png"), Position.Center, false);
            }
            catch (FileException ex)
            {
                message = ex.Message;
            }

            Assert.AreEqual(message, "Inputted Image file doesn't exist");
        }
    }
}