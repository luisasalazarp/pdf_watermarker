using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
using Watermarker.Domain.Exception;
using Watermarker.Domain.ValueObject;

namespace Watermarker.Domain.Test
{
    [TestClass]
    public class PdfTest
    {
        protected string assetsDirectory;

        public PdfTest()
        {
            assetsDirectory =
                Path.Combine(
                    Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.Parent.Parent.Parent.Parent
                        .FullName, "assets");
        }

        [TestMethod]
        public void TestPdfDocumentType()
        {
            string message = string.Empty;
            try
            {
                Pdf pdf = new Pdf(Path.Combine(assetsDirectory, "test.docx"));
            }
            catch (FileFormatException ex)
            {
                message = ex.Message;
            }

            Assert.AreEqual(message, "Invalid document type");
        }

        [TestMethod]
        public void TestPdfFileExist()
        {
            string message = string.Empty;
            try
            {
                Pdf pdf = new Pdf(Path.Combine(assetsDirectory, "test2.pdf"));
            }
            catch (FileException ex)
            {
                message = ex.Message;
            }

            Assert.AreEqual(message, "Inputted PDF file doesn't exist");
        }
    }
}