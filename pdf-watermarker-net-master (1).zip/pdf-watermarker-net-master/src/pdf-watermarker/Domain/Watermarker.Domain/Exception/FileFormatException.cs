﻿namespace Watermarker.Domain.Exception
{
    using System;

    [Serializable]
    public class FileFormatException : DomainException
    {
        public FileFormatException()
        {
        }

        public FileFormatException(string message) : base(message)
        {
        }

        public FileFormatException(string message, Exception inner) : base(message, inner)
        {
        }

        protected FileFormatException(
            System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context)
            : base(info, context)
        {
        }
    }
}