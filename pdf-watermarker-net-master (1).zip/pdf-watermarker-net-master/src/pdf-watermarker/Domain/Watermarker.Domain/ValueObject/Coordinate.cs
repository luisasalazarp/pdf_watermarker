namespace Watermarker.Domain.ValueObject
{
    public class Coordinate
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
}