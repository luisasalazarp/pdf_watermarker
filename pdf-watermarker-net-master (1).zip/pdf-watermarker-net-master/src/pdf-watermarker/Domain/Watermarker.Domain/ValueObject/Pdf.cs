using System.IO;
using Watermarker.Domain.ValueObject.Enum;
using Watermarker.Domain.Exception;

namespace Watermarker.Domain.ValueObject
{
    public class Pdf : Document
    {
        public Pdf(string path) : base(path)
        {
            if (!System.Enum.TryParse(System.IO.Path.GetExtension(Path)?.Replace(".", string.Empty), true,
                out DocumentExtensionType documentExtension))
                throw new FileFormatException("Invalid document type");

            if (string.IsNullOrEmpty(Path) || !File.Exists(Path))
                throw new FileException("Inputted PDF file doesn't exist");

            ExtensionType = documentExtension;
        }
    }
}