﻿using System.IO;
using Watermarker.Domain.ValueObject.Enum;
using Watermarker.Domain.Exception;

namespace Watermarker.Domain.ValueObject
{
    public class Image
    {
        public string Path { get; }
        public double Height { get; }
        public double Width { get; }
        private ImageExtensionType ExtensionType { get; }

        public Image(string path)
        {
            if (!System.Enum.TryParse(System.IO.Path.GetExtension(path).Replace(".", string.Empty), true,
                out ImageExtensionType extension))
                throw new FileFormatException("Invalid image type");

            if (string.IsNullOrEmpty(path) || !File.Exists(path))
                throw new FileException("Inputted Image file doesn't exist");

            Path = path;
            Width = OriginalImage().Width;
            Height = OriginalImage().Height;
            ExtensionType = extension;
        }

        private System.Drawing.Image OriginalImage()
        {
            return System.Drawing.Image.FromFile(Path);
        }
    }
}