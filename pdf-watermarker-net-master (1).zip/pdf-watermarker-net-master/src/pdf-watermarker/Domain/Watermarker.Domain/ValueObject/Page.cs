﻿using Watermarker.Domain.ValueObject.Enum;

namespace Watermarker.Domain.ValueObject
{
    public class Page
    {
        public double Height { get; set; }
        public double Width { get; set; }

        public PageOrientation PageOrientation => Width > Height ? PageOrientation.Landscape : PageOrientation.Portrait;

        public Watermark Watermark { get; set; }

        public Coordinate GetWatermarkCoordinate()
        {
            var coordinate = new Coordinate();

            switch (Watermark.Position)
            {
                case Position.TopLeft:
                    coordinate.X = 0;
                    coordinate.Y = 0;
                    break;
                case Position.TopRight:
                    coordinate.X = Width - Watermark.Width;
                    coordinate.Y = 0;
                    break;
                case Position.BottomRight:
                    coordinate.X = Width - Watermark.Width;
                    coordinate.Y = Height - Watermark.Height;
                    break;
                case Position.BottomLeft:
                    coordinate.X = 0;
                    coordinate.Y = Height - Watermark.Height;
                    break;
                default:
                case Position.Center:
                    coordinate.X = (Width - Watermark.Width) / 2;
                    coordinate.Y = (Height - Watermark.Height) / 2;
                    break;
            }

            return coordinate;
        }
    }
}