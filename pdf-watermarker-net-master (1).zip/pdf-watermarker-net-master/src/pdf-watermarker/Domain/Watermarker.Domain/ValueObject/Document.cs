﻿using System.Collections.Generic;
using System.Linq;
using Watermarker.Domain.ValueObject.Enum;

namespace Watermarker.Domain.ValueObject
{
    public abstract class Document
    {
        public string Path { get; }
        protected DocumentExtensionType ExtensionType { get; set; }
        public IList<Page> Pages { get; set; }
        public int PageCount => Pages.Count;

        protected Document(string path)
        {
            Path = path;
        }

        public Page GetPage(int index)
        {
            return Pages.ElementAt(index);
        }
    }
}