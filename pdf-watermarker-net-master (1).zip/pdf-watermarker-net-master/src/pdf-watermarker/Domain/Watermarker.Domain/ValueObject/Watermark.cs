﻿using Watermarker.Domain.ValueObject.Enum;

namespace Watermarker.Domain.ValueObject
{
    public class Watermark
    {
        public Image Image { get; }
        public Position Position { get; }

        public double Height { get; }
        public double Width { get; }
        public bool Background { get; }

        private const double WidthInMillimeters = 25.4;
        private const double HeightInMillimeters = 96;

        private Watermark(Image image, double height, double width, Position position, bool background)
        {
            Image = image;
            Width = width / HeightInMillimeters * WidthInMillimeters;
            Height = height / HeightInMillimeters * WidthInMillimeters;
            Position = position;
            Background = background;
        }

        public static Watermark CreateWatermark(string path, Position position, bool background)
        {
            Image image = new Image(path);

            return new Watermark(image, image.Height, image.Width, position, background);
        }
    }
}