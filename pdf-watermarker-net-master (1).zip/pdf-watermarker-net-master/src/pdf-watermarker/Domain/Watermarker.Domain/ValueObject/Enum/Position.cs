﻿namespace Watermarker.Domain.ValueObject.Enum
{
    public enum Position
    {
        Center,
        TopLeft,
        TopRight,
        BottomLeft,
        BottomRight
    }
}