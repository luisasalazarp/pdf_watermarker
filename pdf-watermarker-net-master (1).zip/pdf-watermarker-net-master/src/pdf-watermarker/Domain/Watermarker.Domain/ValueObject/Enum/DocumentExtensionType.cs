﻿namespace Watermarker.Domain.ValueObject.Enum
{
    public enum DocumentExtensionType
    {
        Pdf
    }
}