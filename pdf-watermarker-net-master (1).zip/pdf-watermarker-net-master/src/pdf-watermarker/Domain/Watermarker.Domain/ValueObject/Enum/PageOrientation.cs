﻿namespace Watermarker.Domain.ValueObject.Enum
{
    public enum PageOrientation
    {
        Landscape,
        Portrait
    }
}