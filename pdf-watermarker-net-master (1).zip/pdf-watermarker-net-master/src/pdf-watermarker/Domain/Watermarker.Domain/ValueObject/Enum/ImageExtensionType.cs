﻿namespace Watermarker.Domain.ValueObject.Enum
{
    public enum ImageExtensionType
    {
        Png,
        Jpg
    }
}