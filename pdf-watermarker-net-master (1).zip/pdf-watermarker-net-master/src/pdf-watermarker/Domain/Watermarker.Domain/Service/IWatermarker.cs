using Watermarker.Domain.ValueObject;

namespace Watermarker.Domain.Service
{
    public interface IWatermarker<T> where T : Document
    {
        string AddWatermarkToDocument(Watermark watermark, T document);
        string AddWatermarkToDocument(int index, Watermark watermark, T document);
        string AddWatermarkToDocument(int start, int end, Watermark watermark, T document);
    }
}