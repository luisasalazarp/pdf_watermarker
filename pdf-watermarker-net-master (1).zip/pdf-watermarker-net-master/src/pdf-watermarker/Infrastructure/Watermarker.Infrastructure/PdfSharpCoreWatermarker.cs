using System;
using System.Collections.Generic;
using System.IO;
using PdfSharpCore.Drawing;
using PdfSharpCore.Pdf;
using PdfSharpCore.Pdf.IO;
using Watermarker.Domain.ValueObject;
using Watermarker.Domain.ValueObject.Enum;
using Watermarker.Domain.Service;

namespace Watermarker.Infrastructure
{
    public class PdfSharpCoreWatermarker : IWatermarker<Pdf>
    {
        public string AddWatermarkToDocument(Watermark watermark, Pdf document)
        {
            document.Pages = GetDocumentPages(document.Path);
            foreach (Page documentPage in document.Pages)
                documentPage.Watermark = watermark;

            return SaveDocument(document);
        }

        public string AddWatermarkToDocument(int index, Watermark watermark, Pdf document)
        {
            document.Pages = GetDocumentPages(document.Path);
            Page watermarkPage = document.GetPage(index - 1);
            watermarkPage.Watermark = watermark;

            return SaveDocument(document);
        }

        public string AddWatermarkToDocument(int start, int end, Watermark watermark, Pdf document)
        {
            document.Pages = GetDocumentPages(document.Path);
            for (int i = start - 1; i <= end - 1; i++)
            {
                Page page = document.GetPage(i);
                page.Watermark = watermark;
            }

            return SaveDocument(document);
        }

        private IList<Page> GetDocumentPages(string path)
        {
            return GetPageList(PdfReader.Open(path, PdfDocumentOpenMode.Import).Pages);
        }

        private string SaveDocument(Document file)
        {
            PdfDocument pdfDocument = PdfReader.Open(file.Path, PdfDocumentOpenMode.Import);
            PdfDocument pdfNewDocument = new PdfDocument();

            int index = 0;
            foreach (var page in file.Pages)
            {
                pdfNewDocument.AddPage(ImportPage(page, pdfDocument.Pages[index]));

                if (page.Watermark != null) AddImageToPdfPage(page, pdfNewDocument.Pages[index]);

                index++;
            }

            string path = Path.Combine(Path.GetDirectoryName(file.Path) ?? throw new InvalidOperationException(),
                Path.GetFileNameWithoutExtension(file.Path) + "-output.pdf");

            pdfNewDocument.Save(path);

            return path;
        }

        private IList<Page> GetPageList(PdfPages pages)
        {
            var pageList = new List<Page>();

            foreach (var page in pages)
                pageList.Add(new Page
                {
                    Width = page.Width,
                    Height = page.Height
                });

            return pageList;
        }

        private PdfPage ImportPage(Page page, PdfPage pdfPage)
        {
            var pdfNewPage = pdfPage;
            pdfNewPage.Orientation = page.PageOrientation == PageOrientation.Portrait
                ? PdfSharpCore.PageOrientation.Portrait
                : PdfSharpCore.PageOrientation.Landscape;

            pdfNewPage.Width = page.Width;
            pdfNewPage.Height = page.Height;

            return pdfNewPage;
        }

        private void AddImageToPdfPage(Page page, PdfPage pdfPage)
        {
            var imageBackground = page.Watermark.Background
                ? XGraphicsPdfPageOptions.Prepend
                : XGraphicsPdfPageOptions.Append;

            Coordinate coordinate = page.GetWatermarkCoordinate();

            var rectLogo = new XRect(coordinate.X, coordinate.Y, page.Watermark.Width,
                page.Watermark.Height);

            var logo = XImage.FromFile(page.Watermark.Image.Path);

            var gfx = XGraphics.FromPdfPage(pdfPage, imageBackground);
            gfx.DrawImage(logo, rectLogo);
        }
    }
}