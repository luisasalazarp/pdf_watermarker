﻿using Microsoft.AspNetCore.Mvc;
using Watermarker.Application;
using Watermarker.Application.Request;
using Watermarker.Application.Response;
using Watermarker.Infrastructure;

namespace Watermaker.API.Controllers
{
    /// <inheritdoc />
    [ApiController]
    [Route("[controller]")]
    public class SavePdfWithWatermarkIntervalPageController : ControllerBase
    {
        private readonly SavePdfWithWatermarkIntervalPage _savePdfWithWatermarkIntervalPage;

        /// <inheritdoc />
        public SavePdfWithWatermarkIntervalPageController()
        {
            _savePdfWithWatermarkIntervalPage = new SavePdfWithWatermarkIntervalPage(new PdfSharpCoreWatermarker());
        }

        /// <summary>
        /// Creates a new Pdf based on the original one with a watermark in a pages interval.
        /// </summary>
        /// <remarks>
        ///
        /// Position number possibilities in order:
        /// 
        /// Center  = 0
        /// TopLeft = 1
        /// TopRight = 2
        /// BottomLeft = 3
        /// BottomRight = 4
        ///
        /// Sample request using example path for Windows, Mac OS or Linux:
        /// 
        ///     {
        ///        "imagePath": "/Users/UserFolder/Desktop/image.png",
        ///        "documentPath": "C:\Users\UserFolder\Desktop\document.pdf",
        ///        "startPage": 5,
        ///        "endPage": 15,
        ///        "position": 0,
        ///        "isBackground": true
        ///     }
        ///
        /// </remarks>
        /// <param name="request"></param>
        /// <returns>Returns the newly created pdf path</returns>
        /// <response code="200">Returns the newly created pdf path</response>
        /// <response code="400">If there's any error on de request model</response>
        ///  <response code="500">Any other error on the build process</response>
        [HttpPost]
        public SavePdfWithWatermarkIntervalPageResponse Execute(SavePdfWithWatermarkIntervalPageRequest request)
        {
            return _savePdfWithWatermarkIntervalPage.Execute(request);
        }
    }
}