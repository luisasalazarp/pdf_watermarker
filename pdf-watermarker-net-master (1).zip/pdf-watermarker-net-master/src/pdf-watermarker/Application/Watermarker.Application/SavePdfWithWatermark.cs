﻿using Watermarker.Application.Request;
using Watermarker.Application.Response;
using Watermarker.Domain.Service;
using Watermarker.Domain.ValueObject;

namespace Watermarker.Application
{
    public class SavePdfWithWatermark
    {
        private readonly IWatermarker<Pdf> _watermarker;

        public SavePdfWithWatermark(IWatermarker<Pdf> watermarker)
        {
            _watermarker = watermarker;
        }

        public SavePdfWithWatermarkResponse Execute(SavePdfWithWatermarkRequest request)
        {
            Pdf pdf = new Pdf(request.DocumentPath);
            Watermark watermark = Watermark.CreateWatermark(request.ImagePath, request.Position, request.IsBackground);

            return new SavePdfWithWatermarkResponse
            {
                ReturnedFilePath = _watermarker.AddWatermarkToDocument(watermark, pdf)
            };
        }
    }
}