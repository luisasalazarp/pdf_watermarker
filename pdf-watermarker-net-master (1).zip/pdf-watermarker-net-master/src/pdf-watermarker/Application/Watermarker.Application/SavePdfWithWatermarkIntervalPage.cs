﻿using Watermarker.Application.Request;
using Watermarker.Application.Response;
using Watermarker.Domain.Service;
using Watermarker.Domain.ValueObject;

namespace Watermarker.Application
{
    public class SavePdfWithWatermarkIntervalPage
    {
        private readonly IWatermarker<Pdf> _watermarker;

        public SavePdfWithWatermarkIntervalPage(IWatermarker<Pdf> watermarker)
        {
            _watermarker = watermarker;
        }

        public SavePdfWithWatermarkIntervalPageResponse Execute(SavePdfWithWatermarkIntervalPageRequest request)
        {
            Pdf pdf = new Pdf(request.DocumentPath);
            Watermark watermark = Watermark.CreateWatermark(request.ImagePath, request.Position, request.IsBackground);

            return new SavePdfWithWatermarkIntervalPageResponse
            {
                ReturnedFilePath =
                    _watermarker.AddWatermarkToDocument(request.StartPage, request.EndPage, watermark, pdf)
            };
        }
    }
}