﻿using Watermarker.Application.Request;
using Watermarker.Application.Response;
using Watermarker.Domain.ValueObject;
using Watermarker.Domain.Service;

namespace Watermarker.Application
{
    public class SavePdfWithWatermarkSinglePage
    {
        private readonly IWatermarker<Pdf> _watermarker;

        public SavePdfWithWatermarkSinglePage(IWatermarker<Pdf> watermarker)
        {
            _watermarker = watermarker;
        }

        public SavePdfWithWatermarkSinglePageResponse Execute(SavePdfWithWatermarkSinglePageRequest request)
        {
            Pdf pdf = new Pdf(request.DocumentPath);
            Watermark watermark = Watermark.CreateWatermark(request.ImagePath, request.Position, request.IsBackground);

            return new SavePdfWithWatermarkSinglePageResponse
            {
                ReturnedFilePath = _watermarker.AddWatermarkToDocument(request.Index, watermark, pdf)
            };
        }
    }
}