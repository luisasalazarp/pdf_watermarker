﻿namespace Watermarker.Application.Response
{
    public class SavePdfWithWatermarkSinglePageResponse
    {
        public string ReturnedFilePath { get; set; }
    }
}