﻿namespace Watermarker.Application.Response
{
    public class SavePdfWithWatermarkResponse 
    {
        public string ReturnedFilePath { get; set; }
    }
}