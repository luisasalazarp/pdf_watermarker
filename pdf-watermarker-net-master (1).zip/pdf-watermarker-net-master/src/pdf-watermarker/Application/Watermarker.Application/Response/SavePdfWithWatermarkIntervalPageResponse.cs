﻿namespace Watermarker.Application.Response
{
    public class SavePdfWithWatermarkIntervalPageResponse 
    {
        public string ReturnedFilePath { get; set; }
    }
}