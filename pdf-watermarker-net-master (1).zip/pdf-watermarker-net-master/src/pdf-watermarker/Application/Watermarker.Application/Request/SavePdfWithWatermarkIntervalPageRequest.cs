using System.ComponentModel.DataAnnotations;
using Watermarker.Domain.ValueObject.Enum;

namespace Watermarker.Application.Request
{
    public class SavePdfWithWatermarkIntervalPageRequest
    {
        [Required] public string ImagePath { get; set; }
        [Required] public string DocumentPath { get; set; }
        [Required] public int StartPage { get; set; }
        [Required] public int EndPage { get; set; }
        [Required] [Range(0, 4)] public Position Position { get; set; }
        [Required] public bool IsBackground { get; set; }
    }
}